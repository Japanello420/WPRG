<?php
session_start();
if (isset($_COOKIE['s31319'])) {
    echo "<p>Użytkownik wysłał już zgłoszenie.<p>";
    echo"<p><a href='zgloszenia.php'>Zobacz listę zgłoszeń</a></p>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Formularz zgłoszeniowy</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="box">
    <h2>Formularz zgłoszeniowy</h2>
    <form action="formularz.php" method="get">
        <label for="imie">Imię:</label><br>
        <input type="text" id="imie" name="imie" required><br>
        
        <label for="nazwisko">Nazwisko:</label><br>
        <input type="text" id="nazwisko" name="nazwisko" required><br>
        
        <label for="adres_email">Adres adres_email:</label><br>
        <input type="email" id="adres_email" name="adres_email" required><br>
        
        <label for="defekt">Defekt:</label><br>
        <textarea id="defekt" name="defekt" maxlength="255" required></textarea><br>
        
        <input type="submit" value="Prześlij">
    </form>
    <p><a href="zgloszenia.php">Zobacz listę zgłoszeń</a></p>
    </div>
</body>
</html>
