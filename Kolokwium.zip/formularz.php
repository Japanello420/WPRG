<?php
session_start();

if (isset($_GET['imie'], $_GET['nazwisko'], $_GET['adres_email'], $_GET['defekt'])) {
    $_SESSION['form_data'] = $_GET;
    header('Location: podsumowanie.php');
    exit();
} else {
    echo "Nieprawidłowe dane.";
}
?>
