<?php
$servername = "localhost";
$username = "s31319"; 
$password = "s31319"; 
$dbname = "defekty";
?>
