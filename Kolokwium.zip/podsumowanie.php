<?php
session_start();

if (!isset($_SESSION['form_data'])) {
    header('Location: index.php');
    exit();
}
if (isset($_POST['accept'])) {
    setcookie('s31319', date('Y-m-d H:i:s'), time() + 3600, "/");

    require 'config.php';

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Błąd połączenia: " . $conn->connect_error);
    }
    $stmt = $conn->prepare("INSERT INTO zgloszenia (imie, nazwisko, adres_email, defekt) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $_SESSION['form_data']['imie'], $_SESSION['form_data']['nazwisko'], $_SESSION['form_data']['adres_email'], $_SESSION['form_data']['defekt']);
    $stmt->execute();
    $stmt->close();
    $conn->close();

    unset($_SESSION['form_data']);
    header('Location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Podsumowanie</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="box">
    <h2>Podsumowanie zgłoszenia</h2>
    <p><b>Imię:</b> <?php echo htmlspecialchars($_SESSION['form_data']['imie']); ?></p><br>
    <p><b>Nazwisko:</b> <?php echo htmlspecialchars($_SESSION['form_data']['nazwisko']); ?></p><br>
    <p><b>Email:</b> <?php echo htmlspecialchars($_SESSION['form_data']['adres_email']); ?></p><br>
    <p><b>Defekt:</b> <?php echo htmlspecialchars($_SESSION['form_data']['defekt']); ?></p>
    <form action="podsumowanie.php" method="post">
        <input type="submit" name="accept" value="Akceptuj">
    </form>
</div>
</body>
</html>
