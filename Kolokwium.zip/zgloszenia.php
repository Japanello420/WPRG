<?php
session_start();

require 'config.php';

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Błąd połączenia: " . $conn->connect_error);
}
if (isset($_POST['delete'])) {
    $id = $_POST['id'];
    $stmt = $conn->prepare("DELETE FROM zgloszenia WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}
$result = $conn->query("SELECT id, imie, nazwisko, adres_email, defekt FROM zgloszenia");
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Lista zgłoszeń</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="box">
    <h2>Lista zgłoszeń</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Imię</th>
            <th>Nazwisko</th>
            <th>adres_Email</th>
            <th>Defekt</th>
            <th>Akcja</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['id']); ?></td>
            <td><?php echo htmlspecialchars($row['imie']); ?></td>
            <td><?php echo htmlspecialchars($row['nazwisko']); ?></td>
            <td><?php echo htmlspecialchars($row['adres_email']); ?></td>
            <td><?php echo htmlspecialchars($row['defekt']); ?></td>
            <td>
                <form action="zgloszenia.php" method="post">
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    <input type="submit" name="delete" value="Usuń">
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
    <p><a href="index.php">Powrót do formularza</a></p>
    </div>
</body>
</html>

<?php
$conn->close();
?>
